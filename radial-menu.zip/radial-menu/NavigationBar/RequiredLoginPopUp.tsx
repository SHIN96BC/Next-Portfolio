import React from 'react';
import { useRouter } from 'next/router';
import { Image } from 'antd';
import useLoginPopUpButton from 'common/presentation/components/auth/useLoginPopUpButton';
import { useGoogleAnalytics } from 'common/presentation/context/GoogleAnalyticsContext';

interface PropsType {
  closePopUp: () => void;
  redirectTo?: string;
}

const RequiredLoginPopUp = ({ closePopUp, redirectTo }: PropsType) => {
  const [loginFC] = useLoginPopUpButton();
  const { sendGaClickEvent } = useGoogleAnalytics();
  const router = useRouter();

  return (
    <div>
      <div className="fixed top-0 bottom-0 left-0 right-0 bg-none bg-opacity-50 z-[10000]" />
      <div className="overflow-hidden bg-[#fff] fixed top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]  w-[89.33333vw] max-w-[335px] z-[10001]">
        <div>
          <div className="mx-[30px]">
            <div className="h-[80px] mb-[30px] text-center">
              <Image alt="" height="80px" preview={false} src="/icons/icon_circle_Infor_80.svg" width="80px" />
            </div>
            <div className="font-bold text-[18px] leading-[21px]  text-center pb-[20px]">
              로그인이 필요한 서비스입니다.
            </div>
            <div className="text-center text-[#555555] text-[15px] leading-[20px]">
              <div>로그인 하시겠습니까?</div>
            </div>
          </div>
          <div className=" flex flex-col mt-[30px] items-center text-center space-y-[12px]">
            <button
              className="!h-[52px] text-[#555555] leading-[16px]v font-semibold w-[295px] border border-[#D3DBD9] rounded-[5px]"
              onClick={() => {
                sendGaClickEvent({
                  ep_event_page: '공통',
                  ep_event_area: '하단_로그인',
                  ep_event_button: '취소',
                });

                closePopUp();
              }}
              type="button"
            >
              취소
            </button>
            <button
              className="bg-[#009C75]  rounded-[5px] w-[295px] h-[52px]"
              onClick={() => {
                sendGaClickEvent({
                  ep_event_page: '공통',
                  ep_event_area: '하단_로그인',
                  ep_event_button: '확인',
                });

                loginFC().then(() => {
                  if (redirectTo) {
                    router.push(redirectTo);
                  } else {
                    router.replace(router.asPath);
                  }
                });
              }}
              type="button"
            >
              <p className="mb-0 h-[19px] text-[16px] text-center leading-[19px] font-semibold text-[#fff]">확인</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

RequiredLoginPopUp.defaultProps = {
  redirectTo: undefined,
};

export default RequiredLoginPopUp;
