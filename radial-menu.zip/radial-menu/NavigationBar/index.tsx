import ScrollToCustomer from 'common/presentation/components/ScrollToCustomer';
import { useRouter } from 'next/router';
import { useEffect, useMemo, useRef, useState } from 'react';
import Image from 'next/image';
import { useElementSize } from 'usehooks-ts';
import moment from 'moment';
import useLoginPopUpButton from 'common/presentation/components/auth/useLoginPopUpButton';

import PopUp from 'common/presentation/components/common/PopUp';
import { usePopUp } from 'common/presentation/components/pop-ups/provider';
import ScrollToTopButton from 'common/presentation/components/ScrollToTopButton';
import { useGoogleAnalytics } from 'common/presentation/context/GoogleAnalyticsContext';
import ShowGGMapButton from 'common/presentation/components/ShowGGMapButton';
import { RootState, useSelector } from 'common/redux/store';
import { TypeNavigationBar } from 'common/types/layout/typeNav';
import { SliceState } from 'common/types/redux/typeSlice';
import ModalConfirm from 'common/presentation/components/ModalConfirm';
import {
  useGetExtEventGetApplySecondMissionChallengeQuery,
  usePostExtEventDeleteApplySecondMissionChallengeMutation,
  usePostExtEventRegisterMissionChallengeMutation,
} from '@endpoints/ext-event2';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import { useSearchHistoryContext } from 'common/presentation/context/SearchHistoryContext';
import { useGetUserGetNotificationListQuery } from '@endpoints/user2';

import Notification from '../../../../Notification';
import CommonSearchPopup from '../../../../package/product-detail/pop-ups/CommonSearchPopup';

import RadialMenu from '../../../RadialMenu';
import { useSideBar } from '../LeftSideBar/LeftSideBarProvider';
import styles from './index.module.scss';

import { useNavigationBar } from './NavigationBarProvider';

export type NavigationBarAddOnComponentType = (props: unknown) => JSX.Element;
export interface NavigationBarConfig {
  addOnComponent?: JSX.Element;
  addOnComponentConfig?: { Creator: NavigationBarAddOnComponentType; props: Record<string, unknown> };
  showScrollToTopButton?: boolean;
  showGoogleMap?: boolean;
  floatingActions?: JSX.Element[];
  isMoreSpace?: boolean;
}
interface Props {
  onActiveChange?: (value: boolean) => void;
  onNavBarHeightChanged?: (value: number) => void;
  isHideNav?: boolean;
}
function NavigationBar({
  onActiveChange,
  addOnComponent,
  addOnComponentConfig,
  showScrollToTopButton,
  showGoogleMap,
  floatingActions,
  isMoreSpace,
  onNavBarHeightChanged,
  isHideNav,
}: Props & NavigationBarConfig) {
  const router = useRouter();
  const { active, setActive } = useNavigationBar();
  const { sendGaClickEvent } = useGoogleAnalytics();
  const { showPopUp } = usePopUp();
  const { showSideBar } = useSideBar();
  const { isSrcolling, scrollPercentage, stopScroll } = useSelector((state: SliceState) => state.uiState);
  const [addOnComponentRef, { height }] = useElementSize();
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const { setIsLoadedDataSearch } = useSearchHistoryContext();
  const [loginFC] = useLoginPopUpButton();
  const [type, setType] = useState<TypeNavigationBar>('1');
  const { data: notifications } = useGetUserGetNotificationListQuery(
    {
      pageNo: 1,
      totalRecord: 1,
      type: 'notifications',
    },
    {
      skip: !accessToken,
    }
  );

  const hasUnreadNotification =
    notifications?.result?.totalNotifications !== undefined &&
    notifications?.result?.totalNotifications !== null &&
    notifications?.result?.totalNotifications > 0;

  const heightRef = useRef(height);

  useEffect(() => {
    if (router.pathname === '/') {
      setType('1');
    } else {
      setType('2');
    }
  }, [router.pathname]);

  useEffect(() => {
    if (height !== heightRef.current) {
      heightRef.current = height;
      if (isMoreSpace) onNavBarHeightChanged?.(height + 184);
      else {
        onNavBarHeightChanged?.(height + 64);
      }
    }
  }, [height]);

  useEffect(() => {
    router.events.on('routeChangeStart', () => setActive(undefined));
    router.events.on('hashChangeStart', () => setActive(undefined));
  }, []);

  const { Creator: AddOnComponent, props: addOnProps } = addOnComponentConfig ?? {};

  const { data: checkApplySecondMission2 } = useGetExtEventGetApplySecondMissionChallengeQuery({
    eventNo: Number(process.env.NEXT_PUBLIC_EVENT_NO),
  });

  const [triggerRegisterMissionChallenge, { data: rigisterData }] = usePostExtEventRegisterMissionChallengeMutation();
  const [triggerDelApplyMissionChallenge] = usePostExtEventDeleteApplySecondMissionChallengeMutation();
  const [isSuccessMission2, setIsSuccessMission2] = useState(false);

  const isShowMission2 = useMemo(() => {
    return (
      !!accessToken &&
      checkApplySecondMission2?.result?.status === 'Applied' &&
      moment().isBefore(moment(checkApplySecondMission2?.result?.eventMission?.missionEndDateTime)) &&
      rigisterData?.result !== 'S' &&
      window.location.pathname?.includes('/package/')
    );
  }, [checkApplySecondMission2, accessToken, rigisterData]);

  const onClickLuky = () => {
    triggerRegisterMissionChallenge({
      registerMissionChallengeRequest: {
        challengContent: '',
        eventMasterId: process.env.NEXT_PUBLIC_EVENT_MASTER_ID,
        eventMissionId: checkApplySecondMission2?.result?.eventMission?.eventMissionId ?? '',
        missionCouponInfos: '',
      },
    })
      .unwrap()
      .then((res) => {
        if (res?.result === 'S') {
          setIsSuccessMission2(true);

          triggerDelApplyMissionChallenge({
            eventNo: Number(process.env.NEXT_PUBLIC_EVENT_NO),
          });
        }
      });
  };

  if (router.pathname === '/reservation-policy') return null; // FIXME : 안 바쁠 때 Props 로 수정 필요

  return (
    <div className="fixed bottom-0 w-full z-[1002]">
      <div
        className={`navigation_bar ${styles.navigationBar} ${
          !isHideNav && !stopScroll && isSrcolling && scrollPercentage < 0.998 && styles.active
        } ${router.pathname === '/hotel/map' && styles.disbaleNavbar}`}
      >
        <div
          aria-hidden
          className={`absolute bottom-[145px] left-[25%] w-[90px] z-[30] ${isShowMission2 ? '' : 'hidden'}`}
          onClick={onClickLuky}
        >
          <Image alt="" height={110} src="/images/event/event_luky_icon.png" width={90} />
        </div>

        <div className="flex flex-col w-full items-stretch">
          <div
            className={`flex flex-col items-end ${styles.attachments} ${active === true && styles.active}  ${
              active === false && styles.deActive
            }`}
            id="footer-container"
          >
            <div className="absolute flex flex-col mb-[25px] bottom-[100%] right-0 space-y-[10px]">
              {router?.pathname.includes('/m-time-deal') && <ScrollToCustomer />}
              {showScrollToTopButton && <ScrollToTopButton />}
              {floatingActions}
            </div>
            <div className="absolute flex flex-col bottom-[100%] right-[20px] space-y-[10px]">
              {(router.pathname.includes('/hotel/search-result') || router.pathname.includes('/hotel/time-deal')) &&
                showGoogleMap && <ShowGGMapButton />}
            </div>
            <div className="self-stretch relative" ref={addOnComponentRef}>
              {addOnComponent}
              {AddOnComponent ? <AddOnComponent {...addOnProps} /> : undefined}
              {(addOnComponent || addOnComponentConfig) && (
                <div className="absolute top-[100%] bg-white h-[50px] w-full" />
              )}
            </div>
          </div>
          {!isHideNav && (
            <div className="flex h-[65px]">
              <div
                className={`${styles.left} ${active === true && styles.active}  ${active === false && styles.deActive}`}
              >
                {type === '1' && (
                  <>
                    <div className={styles.menu}>
                      <svg
                        className="!bg-transparent"
                        height="26"
                        id="icon_menu_26"
                        onClick={() => {
                          sendGaClickEvent({
                            ep_event_page: '공통',
                            ep_event_area: '하단',
                            ep_event_button: '메뉴',
                          });

                          showSideBar();
                        }}
                        viewBox="0 0 26 26"
                        width="26"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <rect data-name="사각형 826" fill="none" height="26" id="사각형_826" width="26" />
                        <g data-name="그룹 934" id="그룹_934" transform="translate(-1.422 -1)">
                          <path
                            d="M4.9,5.107H23.489"
                            data-name="패스 9977"
                            fill="none"
                            id="패스_9977"
                            stroke="#111"
                            strokeLinecap="round"
                            strokeWidth="2"
                            transform="translate(0.226 1.893)"
                          />
                          <path
                            d="M4.9,5.107H23.489"
                            data-name="패스 9978"
                            fill="none"
                            id="패스_9978"
                            stroke="#111"
                            strokeLinecap="round"
                            strokeWidth="2"
                            transform="translate(0.226 8.893)"
                          />
                          <path
                            d="M4.9,5.107H23.489"
                            data-name="패스 9979"
                            fill="none"
                            id="패스_9979"
                            stroke="#111"
                            strokeLinecap="round"
                            strokeWidth="2"
                            transform="translate(0.226 15.893)"
                          />
                        </g>
                      </svg>
                      <p className={styles.menuTitle}>전체메뉴</p>
                    </div>

                    <div
                      className={styles.alarm}
                      onClick={() => {
                        sendGaClickEvent({
                          ep_event_page: '공통',
                          ep_event_area: '하단',
                          ep_event_button: '알림',
                        });
                        if (window?.AppBridge?.callNative?.goPushList?.() === false) {
                          showPopUp(PopUp, {
                            title: '알림내역',
                            content: <Notification />,
                          });
                        }
                      }}
                      onKeyPress={undefined}
                      role="button"
                      tabIndex={0}
                    >
                      <svg
                        className="!bg-transparent"
                        height="26"
                        id="icon_alarm_26"
                        viewBox="0 0 26 26"
                        width="26"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <rect data-name="사각형 826" fill="none" height="26" id="사각형_826" width="26" />
                        <g data-name="그룹 635" id="그룹_635" transform="translate(3.151 1.27)">
                          <path
                            d="M3759.387-9856.361a1.53,1.53,0,0,1-1.371-.846,1.53,1.53,0,0,1,.136-1.606l.865-1.17a6.035,6.035,0,0,0,1.173-3.562v-3.619a7.705,7.705,0,0,1,1.349-4.367,7.785,7.785,0,0,1,3.309-2.744,3.106,3.106,0,0,1,3.1-2.994,3.107,3.107,0,0,1,3.1,2.994,7.785,7.785,0,0,1,3.309,2.744,7.722,7.722,0,0,1,1.346,4.367v3.619a6.037,6.037,0,0,0,1.175,3.563l.865,1.17a1.531,1.531,0,0,1,.136,1.606,1.53,1.53,0,0,1-1.371.846Zm2.538-10.8v3.619a7.774,7.774,0,0,1-1.514,4.594l-.632.855h16.338l-.63-.855a7.77,7.77,0,0,1-1.515-4.594v-3.619a6.03,6.03,0,0,0-6.024-6.023A6.03,6.03,0,0,0,3761.925-9867.165Zm4.829-7.664a7.749,7.749,0,0,1,2.209-.027l-.369-.5-.677-.179A1.374,1.374,0,0,0,3766.754-9874.829Z"
                            data-name="합치기 5"
                            fill="#111"
                            id="합치기_5"
                            transform="translate(-3758.1 9877.02)"
                          />
                          <path
                            d="M3758.279-9875.654a.869.869,0,0,1-.4-.531.867.867,0,0,1,.092-.656.866.866,0,0,1,.749-.429.868.868,0,0,1,.436.116,4.38,4.38,0,0,0,1.257.432,4.328,4.328,0,0,0,.781.074,3.607,3.607,0,0,0,1.852-.5.889.889,0,0,1,.439-.118.872.872,0,0,1,.749.429.857.857,0,0,1,.089.656.866.866,0,0,1-.4.531,5.33,5.33,0,0,1-2.732.743A6.153,6.153,0,0,1,3758.279-9875.654Z"
                            data-name="합치기 6"
                            fill="#111"
                            id="합치기_6"
                            transform="translate(-3751.25 9898.62)"
                          />
                        </g>
                        {hasUnreadNotification ? (
                          <circle
                            cx="3"
                            cy="3"
                            fill="#ed4949"
                            id="icon_GNB_alarm_new"
                            r="3"
                            transform="translate(20)"
                          />
                        ) : null}
                      </svg>
                      <p className={styles.menuTitle}>알림</p>
                    </div>
                  </>
                )}
                {type !== '1' && (
                  <>
                    <div
                      className={styles.back}
                      onClick={() => {
                        sendGaClickEvent({
                          ep_event_page: '공통',
                          ep_event_area: '하단',
                          ep_event_button: '뒤로가기',
                        });
                        router.back();
                      }}
                      onKeyPress={undefined}
                      role="button"
                      tabIndex={0}
                    >
                      <svg
                        className="!bg-transparent"
                        height="26"
                        id="icon_back_26"
                        viewBox="0 0 26 26"
                        width="26"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <rect data-name="사각형 845" fill="none" height="26" id="사각형_845" width="26" />
                        <path
                          d="M3982.738-9856.287l-11.337-8.918a1.046,1.046,0,0,1-.4-.825,1.041,1.041,0,0,1,.4-.825l11.337-8.921a1.038,1.038,0,0,1,.647-.223,1.046,1.046,0,0,1,.828.4,1.055,1.055,0,0,1-.176,1.476l-10.289,8.095,10.289,8.095a1.046,1.046,0,0,1,.392.7,1.044,1.044,0,0,1-.216.773,1.049,1.049,0,0,1-.828.4A1.029,1.029,0,0,1,3982.738-9856.287Z"
                          data-name="합치기 10"
                          fill="#111"
                          id="합치기_10"
                          transform="translate(-3964.719 9879.03)"
                        />
                      </svg>
                      <p className={`${styles.menuTitle} !text-white`}>뒤로가기</p>
                    </div>
                    <div
                      className={styles.forward}
                      onClick={() => {
                        sendGaClickEvent({
                          ep_event_page: '공통',
                          ep_event_area: '하단',
                          ep_event_button: '앞으로가기',
                        });
                        window.history.forward();
                      }}
                      onKeyPress={undefined}
                      role="button"
                      tabIndex={0}
                    >
                      <svg
                        className="!bg-transparent"
                        height="26"
                        id="icon_forward_26"
                        viewBox="0 0 26 26"
                        width="26"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <rect data-name="사각형 845" fill="none" height="26" id="사각형_845" width="26" />
                        <path
                          d="M3921.225-9856.463a1.046,1.046,0,0,1-.218-.773,1.049,1.049,0,0,1,.394-.7l10.289-8.095-10.289-8.095a1.052,1.052,0,0,1-.176-1.476,1.041,1.041,0,0,1,.825-.4,1.045,1.045,0,0,1,.649.223l11.337,8.921a1.046,1.046,0,0,1,.4.825,1.051,1.051,0,0,1-.4.825l-11.337,8.918a1.036,1.036,0,0,1-.649.226A1.044,1.044,0,0,1,3921.225-9856.463Z"
                          data-name="합치기 9"
                          fill="#111"
                          id="합치기_9"
                          transform="translate(-3914.718 9879.03)"
                        />
                      </svg>
                      <p className={`${styles.menuTitle} !text-white`}>앞으로가기</p>
                    </div>
                    <div className={styles.refresh}>
                      <svg
                        className="!bg-transparent"
                        height="26"
                        onClick={() => {
                          sendGaClickEvent({
                            ep_event_page: '공통',
                            ep_event_area: '하단',
                            ep_event_button: '새로고침',
                          });
                          router.reload();
                        }}
                        viewBox="0 0 26 26"
                        width="26"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <g id="icon_refresh_26" transform="translate(-120 -743)">
                          <rect
                            data-name="사각형 1041"
                            fill="none"
                            height="26"
                            id="사각형_1041"
                            transform="translate(120 743)"
                            width="26"
                          />
                          <path
                            d="M184.522,228.278a1.079,1.079,0,0,0-1.214.924,8.783,8.783,0,1,1-8.7-9.976,8.709,8.709,0,0,1,6.362,2.726l-1.43,1.344,2.886.87,2.886.87-.689-2.934-.689-2.934-1.392,1.308a11.038,11.038,0,0,0-2.986-2.228,10.94,10.94,0,1,0,5.893,11.244A1.079,1.079,0,0,0,184.522,228.278Z"
                            data-name="패스 9973"
                            fill="#231815"
                            id="패스_9973"
                            transform="translate(-41.562 527.991)"
                          />
                          <path
                            d="M174.606,239a10.989,10.989,0,1,1,0-21.979,10.959,10.959,0,0,1,7.935,3.387l1.419-1.333,1.418,6.037-5.937-1.79,1.457-1.369a8.632,8.632,0,0,0-6.291-2.674,8.732,8.732,0,1,0,8.653,9.92,1.132,1.132,0,0,1,1.117-.977,1.144,1.144,0,0,1,.153.01,1.129,1.129,0,0,1,.966,1.27,10.98,10.98,0,0,1-10.889,9.5Zm0-21.879a10.889,10.889,0,1,0,10.79,12.367,1.029,1.029,0,0,0-.881-1.158,1.042,1.042,0,0,0-.14-.009,1.032,1.032,0,0,0-1.018.89,8.833,8.833,0,1,1-8.752-10.033,8.732,8.732,0,0,1,6.4,2.742l.035.036-1.4,1.319,5.606,1.69-1.339-5.7-1.365,1.283-.034-.036a10.854,10.854,0,0,0-7.9-3.392Z"
                            data-name="패스 9973 - 윤곽선"
                            fill="#fff"
                            id="패스_9973_-_윤곽선"
                            transform="translate(-41.562 527.991)"
                          />
                        </g>
                      </svg>
                      <p className={styles.menuTitle}>새로고침</p>
                    </div>
                  </>
                )}
              </div>
              <div
                className={`${styles.center} ${active === true && styles.active}   ${
                  active === false && styles.deActive
                }`}
              >
                <div className={`${styles.rec} ${active && styles.active} ${!active && styles.deActive}`} />
                <div className={styles.logo} style={{ top: active ? -24 : -5 }}>
                  <svg
                    className="!bg-transparent"
                    height="65"
                    onClick={() => {
                      setActive(!active);
                      onActiveChange?.(!active);
                      if (!active) {
                        document.body.style.overflow = 'hidden';
                      } else {
                        document.body.style.overflow = 'unset';
                      }
                    }}
                    viewBox="0 0 65 65"
                    width="65"
                    xmlns="http://www.w3.org/2000/svg"
                    xmlnsXlink="http://www.w3.org/1999/xlink"
                  >
                    <defs>
                      <filter filterUnits="userSpaceOnUse" height="65" id="사각형_1042" width="65" x="0" y="0">
                        <feOffset in="SourceAlpha" />
                        <feGaussianBlur result="blur" stdDeviation="3" />
                        <feFlood floodColor="#009c75" floodOpacity="0.702" />
                        <feComposite in2="blur" operator="in" />
                        <feComposite in="SourceGraphic" />
                      </filter>
                    </defs>
                    <g id="icon_Mdial_26" transform="translate(-155 -709)">
                      <g filter="url(#사각형_1042)" transform="matrix(1, 0, 0, 1, 155, 709)">
                        <rect
                          data-name="사각형 1042"
                          fill="#009c75"
                          height="47"
                          id="사각형_1042-2"
                          rx="23.5"
                          transform="translate(9 9)"
                          width="47"
                        />
                      </g>
                      <g id="M다이얼">
                        <rect
                          data-name="사각형 1076"
                          fill="#009c75"
                          height="37"
                          id="사각형_1076"
                          rx="18.5"
                          transform="translate(169 723)"
                          width="37"
                        />
                        <path
                          d="M71.737,10.172h-4.83L62.838,22.539,58.792,10.172h-1.67a3.2,3.2,0,0,0-2.442.849A3.648,3.648,0,0,0,53.8,13.33l-.945,14.99h4.15l.629-9.7,3.271,9.7H64.79l3.272-9.7.63,9.7h4.15Z"
                          data-name="패스 9974"
                          fill="#fff"
                          id="패스_9974"
                          transform="translate(124.65 722.254)"
                        />
                      </g>
                    </g>
                  </svg>
                </div>
              </div>
              <div
                className={`${styles.right} ${active === true && styles.active} ${active === false && styles.deActive}`}
              >
                {type === '1' && (
                  <div
                    className={styles.search}
                    onClick={() => {
                      sendGaClickEvent({
                        ep_event_page: '공통',
                        ep_event_area: '하단',
                        ep_event_button: '검색',
                      });
                      setIsLoadedDataSearch(false);
                      showPopUp(PopUp, {
                        title: '',
                        content: <CommonSearchPopup />,
                        closeLeft: true,
                        isTopSpace: false,
                      });
                    }}
                    role="presentation"
                  >
                    <svg
                      className="!bg-transparent"
                      height="26"
                      viewBox="0 0 26 26"
                      width="26"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <g id="icon_search_26" transform="translate(-278 -9677)">
                        <g data-name="그룹 899" id="그룹_899" transform="translate(19.498 9504.586)">
                          <path
                            d="M3969.451-9686.394a10,10,0,0,1-2.949-7.12,10,10,0,0,1,2.949-7.121,10,10,0,0,1,7.123-2.951,10,10,0,0,1,7.121,2.951,10,10,0,0,1,2.949,7.121,10,10,0,0,1-2.949,7.12,10.005,10.005,0,0,1-7.121,2.949A10.006,10.006,0,0,1,3969.451-9686.394Zm-1.14-7.12a8.271,8.271,0,0,0,8.263,8.26,8.271,8.271,0,0,0,8.26-8.26,8.271,8.271,0,0,0-8.26-8.263A8.272,8.272,0,0,0,3968.312-9693.514Z"
                            data-name="합치기 4"
                            fill="#111"
                            id="합치기_4"
                            transform="translate(-3706.053 9877.946)"
                          />
                          <path
                            d="M3971.351-9697.459l-4.583-4.581a.907.907,0,0,1,0-1.281.9.9,0,0,1,.638-.265.9.9,0,0,1,.64.265l4.583,4.584a.9.9,0,0,1,0,1.278.889.889,0,0,1-.64.266A.888.888,0,0,1,3971.351-9697.459Z"
                            data-name="합치기 3"
                            fill="#111"
                            id="합치기_3"
                            transform="translate(-3690.339 9893.66)"
                          />
                        </g>
                        <rect
                          data-name="사각형 1040"
                          fill="none"
                          height="26"
                          id="사각형_1040"
                          transform="translate(278 9677)"
                          width="26"
                        />
                      </g>
                    </svg>
                    <p className={styles.menuTitle}>검색</p>
                  </div>
                )}
                {type !== '1' && (
                  <>
                    <div
                      className={styles.alarm}
                      onClick={() => {
                        sendGaClickEvent({
                          ep_event_page: '공통',
                          ep_event_area: '하단',
                          ep_event_button: '알림',
                        });
                        if (window?.AppBridge?.callNative?.goPushList?.() === false) {
                          showPopUp(PopUp, {
                            title: '알림내역',
                            content: <Notification />,
                          });
                        }
                      }}
                      role="presentation"
                    >
                      <svg
                        className="!bg-transparent"
                        height="26"
                        id="icon_alarm_26"
                        viewBox="0 0 26 26"
                        width="26"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <rect data-name="사각형 826" fill="none" height="26" id="사각형_826" width="26" />
                        <g data-name="그룹 635" id="그룹_635" transform="translate(3.151 1.27)">
                          <path
                            d="M3759.387-9856.361a1.53,1.53,0,0,1-1.371-.846,1.53,1.53,0,0,1,.136-1.606l.865-1.17a6.035,6.035,0,0,0,1.173-3.562v-3.619a7.705,7.705,0,0,1,1.349-4.367,7.785,7.785,0,0,1,3.309-2.744,3.106,3.106,0,0,1,3.1-2.994,3.107,3.107,0,0,1,3.1,2.994,7.785,7.785,0,0,1,3.309,2.744,7.722,7.722,0,0,1,1.346,4.367v3.619a6.037,6.037,0,0,0,1.175,3.563l.865,1.17a1.531,1.531,0,0,1,.136,1.606,1.53,1.53,0,0,1-1.371.846Zm2.538-10.8v3.619a7.774,7.774,0,0,1-1.514,4.594l-.632.855h16.338l-.63-.855a7.77,7.77,0,0,1-1.515-4.594v-3.619a6.03,6.03,0,0,0-6.024-6.023A6.03,6.03,0,0,0,3761.925-9867.165Zm4.829-7.664a7.749,7.749,0,0,1,2.209-.027l-.369-.5-.677-.179A1.374,1.374,0,0,0,3766.754-9874.829Z"
                            data-name="합치기 5"
                            fill="#111"
                            id="합치기_5"
                            transform="translate(-3758.1 9877.02)"
                          />
                          <path
                            d="M3758.279-9875.654a.869.869,0,0,1-.4-.531.867.867,0,0,1,.092-.656.866.866,0,0,1,.749-.429.868.868,0,0,1,.436.116,4.38,4.38,0,0,0,1.257.432,4.328,4.328,0,0,0,.781.074,3.607,3.607,0,0,0,1.852-.5.889.889,0,0,1,.439-.118.872.872,0,0,1,.749.429.857.857,0,0,1,.089.656.866.866,0,0,1-.4.531,5.33,5.33,0,0,1-2.732.743A6.153,6.153,0,0,1,3758.279-9875.654Z"
                            data-name="합치기 6"
                            fill="#111"
                            id="합치기_6"
                            transform="translate(-3751.25 9898.62)"
                          />
                        </g>
                        {hasUnreadNotification ? (
                          <circle
                            cx="3"
                            cy="3"
                            fill="#ed4949"
                            id="icon_GNB_alarm_new"
                            r="3"
                            transform="translate(20)"
                          />
                        ) : null}
                      </svg>
                      <p className={styles.menuTitle}>알림</p>
                    </div>
                    <div
                      className={styles.search}
                      onClick={() => {
                        sendGaClickEvent({
                          ep_event_page: '공통',
                          ep_event_area: '하단',
                          ep_event_button: '검색',
                        });
                        setIsLoadedDataSearch(false);
                        showPopUp(PopUp, {
                          title: '',
                          content: <CommonSearchPopup />,
                          closeLeft: true,
                          isTopSpace: false,
                        });
                      }}
                      onKeyPress={undefined}
                      role="button"
                      tabIndex={0}
                    >
                      <svg
                        className="!bg-transparent"
                        height="26"
                        viewBox="0 0 26 26"
                        width="26"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <g id="icon_search_26" transform="translate(-278 -9677)">
                          <g data-name="그룹 899" id="그룹_899" transform="translate(19.498 9504.586)">
                            <path
                              d="M3969.451-9686.394a10,10,0,0,1-2.949-7.12,10,10,0,0,1,2.949-7.121,10,10,0,0,1,7.123-2.951,10,10,0,0,1,7.121,2.951,10,10,0,0,1,2.949,7.121,10,10,0,0,1-2.949,7.12,10.005,10.005,0,0,1-7.121,2.949A10.006,10.006,0,0,1,3969.451-9686.394Zm-1.14-7.12a8.271,8.271,0,0,0,8.263,8.26,8.271,8.271,0,0,0,8.26-8.26,8.271,8.271,0,0,0-8.26-8.263A8.272,8.272,0,0,0,3968.312-9693.514Z"
                              data-name="합치기 4"
                              fill="#111"
                              id="합치기_4"
                              transform="translate(-3706.053 9877.946)"
                            />
                            <path
                              d="M3971.351-9697.459l-4.583-4.581a.907.907,0,0,1,0-1.281.9.9,0,0,1,.638-.265.9.9,0,0,1,.64.265l4.583,4.584a.9.9,0,0,1,0,1.278.889.889,0,0,1-.64.266A.888.888,0,0,1,3971.351-9697.459Z"
                              data-name="합치기 3"
                              fill="#111"
                              id="합치기_3"
                              transform="translate(-3690.339 9893.66)"
                            />
                          </g>
                          <rect
                            data-name="사각형 1040"
                            fill="none"
                            height="26"
                            id="사각형_1040"
                            transform="translate(278 9677)"
                            width="26"
                          />
                        </g>
                      </svg>
                      <p className={styles.menuTitle}>검색</p>
                    </div>
                  </>
                )}
                <div className={styles.myPage}>
                  <svg
                    className="!bg-transparent"
                    height="26"
                    onClick={async () => {
                      sendGaClickEvent({
                        ep_event_page: '공통',
                        ep_event_area: '하단',
                        ep_event_button: '마이페이지',
                      });

                      if (!accessToken) {
                        const loginResponse: Oidc.User | unknown = await loginFC();
                        if ((loginResponse as Oidc.User).access_token) {
                          router.push('/my-page');
                        } else {
                          router.push('/');
                        }
                      } else {
                        router.push('/my-page');
                      }
                    }}
                    viewBox="0 0 26 26"
                    width="26"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <g id="icon_mypage_26" transform="translate(-21 -3132.373)">
                      <rect
                        data-name="사각형 847"
                        fill="none"
                        height="26"
                        id="사각형_847"
                        transform="translate(21 3132.373)"
                        width="26"
                      />
                      <g data-name="그룹 633" id="그룹_633" transform="translate(22.89 3133.241)">
                        <path
                          d="M3660.934-9861.82a7.232,7.232,0,0,1-7.223-7.226,7.231,7.231,0,0,1,7.223-7.224,7.231,7.231,0,0,1,7.223,7.224A7.232,7.232,0,0,1,3660.934-9861.82Zm0-12.711a5.492,5.492,0,0,0-5.486,5.485,5.493,5.493,0,0,0,5.486,5.488,5.493,5.493,0,0,0,5.486-5.488A5.492,5.492,0,0,0,3660.934-9874.531Z"
                          data-name="빼기 7"
                          fill="#111"
                          id="빼기_7"
                          transform="translate(-3649.604 9876.568)"
                        />
                        <path
                          d="M3674.9-9867.683h-20.323a.858.858,0,0,1-.647-.293.871.871,0,0,1-.216-.676c.377-3.294,1.265-5.69,2.714-7.325a.864.864,0,0,1,.649-.293.864.864,0,0,1,.575.221.871.871,0,0,1,.293.6.86.86,0,0,1-.218.627,10.046,10.046,0,0,0-2.1,5.052l-.062.35h18.34l-.06-.35a10.074,10.074,0,0,0-2.1-5.052.857.857,0,0,1-.217-.627.862.862,0,0,1,.291-.6.865.865,0,0,1,.575-.221.864.864,0,0,1,.649.293c1.45,1.636,2.338,4.031,2.714,7.325a.864.864,0,0,1-.216.676A.858.858,0,0,1,3674.9-9867.683Z"
                          data-name="빼기 6"
                          fill="#111"
                          id="빼기_6"
                          transform="translate(-3653.41 9891.21)"
                        />
                      </g>
                    </g>
                  </svg>
                  <p className={styles.menuTitle}>마이페이지</p>
                </div>
              </div>

              <div className={`${styles.RadialMenu}`}>
                <RadialMenu
                  active={active}
                  onClose={() => {
                    setActive(false);
                    document.body.style.overflow = 'unset';
                  }}
                />
              </div>
            </div>
          )}
        </div>
      </div>
      <ModalConfirm
        content={
          <div>
            30days with 모두투어 챌린지
            <br />
            두번째 미션 성공을 축하드립니다.
            <br />
            지금 호텔 5% 할인쿠폰이 지급되었습니다.
            <br />
            마이페이지에서 확인하세요.
          </div>
        }
        customStyleAlert="px-[20px] py-[50px]"
        handleCancel={() => setIsSuccessMission2(false)}
        handleOk={() => setIsSuccessMission2(false)}
        isCancel={false}
        isModalOpen={isSuccessMission2}
      />
    </div>
  );
}
NavigationBar.defaultProps = {
  onActiveChange: undefined,
  addOnComponent: undefined,
  addOnComponentConfig: undefined,
  showScrollToTopButton: true,
  showGoogleMap: false,
  floatingActions: undefined,
  onNavBarHeightChanged: undefined,
  isMoreSpace: true,
  isHideNav: false,
};
export default NavigationBar;
