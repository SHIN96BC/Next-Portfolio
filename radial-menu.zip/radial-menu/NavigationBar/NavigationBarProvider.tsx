import { usePopUp } from 'common/presentation/components/pop-ups/provider';
import { useRouter } from 'next/router';
import React, { useContext, useEffect, useMemo, useState } from 'react';

import NavigationBar, { NavigationBarConfig } from '.';

interface NavigationBarContextInterface {
  setNavigationBarConfig: (config: NavigationBarConfig) => void;
  active: boolean | undefined;
  setActive: React.Dispatch<boolean | undefined>;
  setHideNavbar: React.Dispatch<boolean>;
  hideNavbar: boolean;
}
const NavigationBarContext = React.createContext<NavigationBarContextInterface | undefined>(undefined);

const NavigationBarProvider = ({
  children,
  isHideNav,
}: {
  children: JSX.Element | JSX.Element[];
  isHideNav?: boolean;
}) => {
  const [active, setActive] = useState<undefined | boolean>(undefined);
  const { openingPopUp } = usePopUp();
  const [hideNavbar, setHideNavbar] = useState<boolean>(false);
  const [navigationBarConfig, setNavigationBarConfig] = useState<NavigationBarConfig>({});
  const setNavigationBarConfigExport = (config: NavigationBarConfig) => {
    setNavigationBarConfig({ ...navigationBarConfig, ...config });
  };
  const [navBarHeight, setNavBarHeight] = useState(84);
  const router = useRouter();
  const providerValue = useMemo(
    () => ({
      setNavigationBarConfig: setNavigationBarConfigExport,
      setActive,
      active,
      setHideNavbar,
      hideNavbar,
    }),
    [active]
  );
  useEffect(() => {
    const handleRouteChange = () => {
      setNavigationBarConfig({});
    };
    router.events.on('routeChangeStart', handleRouteChange);
  }, []);

  return (
    <NavigationBarContext.Provider value={providerValue}>
      {children}
      <div
        className={`${(openingPopUp[openingPopUp.length - 1]?.options?.hideNavigationBar || hideNavbar) && 'hidden'}`}
      >
        <NavigationBar
          {...{
            ...navigationBarConfig,
            ...(openingPopUp[openingPopUp.length - 1]?.options?.navigationBarOptions ?? {}),
          }}
          isHideNav={isHideNav}
          onNavBarHeightChanged={setNavBarHeight}
        />
      </div>
      {router.pathname !== '/hotel/map' && router.pathname !== '/' && router.pathname !== '/flights' ? (
        <div style={{ height: `${navBarHeight}px` }} />
      ) : null}
    </NavigationBarContext.Provider>
  );
};

const useNavigationBar = () => {
  const popups = useContext(NavigationBarContext);
  if (popups == null) {
    throw new Error('useNavigationBar() called outside of a NavigationBarProvider?'); // an alert is not placed because this is an error for the developer not the user
  }
  return popups;
};
NavigationBarProvider.defaultProps = {
  isHideNav: false,
};

export { NavigationBarProvider, useNavigationBar };
