import React from 'react';

function CardItem({ content, handleAction }: { content: JSX.Element | string; handleAction?: () => void }) {
  return (
    <div
      className="px-[20px] w-[73.82%] min-h-[131px]  bg-white rounded-[10px] shadow-[0px_0px_6px_#111111] "
      onClick={handleAction}
      role="presentation"
    >
      {content}
    </div>
  );
}

CardItem.defaultProps = {
  handleAction: () => {},
};

export default CardItem;
