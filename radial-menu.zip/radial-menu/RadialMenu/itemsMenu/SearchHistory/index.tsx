import Image from 'next/image';
import React, { useEffect, useState } from 'react';
import BasicButton from 'common/presentation/components/buttons/BasicButton';
import { usePopUp } from 'common/presentation/components/pop-ups/provider';
import { useSearchHistoryContext } from 'common/presentation/context/SearchHistoryContext';
import PopUp from 'common/presentation/components/common/PopUp';
import moment from 'moment';
import customMapUseIndex from 'common/utils/customMapUseIndex';
import Link from 'next/link';
import { labelTypeSearch, SearchHistoryType } from 'common/presentation/context/SearchHistoryContext/type';
import RecentSearchMain from '../../../../RecentSearchMain';
import InformationSearch from '../../../../package/product-detail/pop-ups/CommonSearchPopup/RecentSearch/InformationSearch';

function SearchHistory() {
  const { searchHistory, updateSearchHistoryByType } = useSearchHistoryContext();
  const [allTypeSearchHistory, setAllTypeSearchHistory] = useState<any>([]);
  const { showPopUp } = usePopUp();

  useEffect(() => {
    let listSearch: any[] = [];
    searchHistory.forEach((itemSearchType: SearchHistoryType, indexSearchType) => {
      itemSearchType.json.forEach((itemSearch, indexSearch) => {
        listSearch.push({
          ...itemSearch,
          id: `${indexSearchType}_${indexSearch}`,
          typeName: labelTypeSearch[itemSearchType.type],
          type: itemSearchType.type,
        });
      });
    });
    listSearch.sort((a: any, b: any) => {
      if (!b?.timeSearch) {
        return -1;
      }
      if (moment(a?.timeSearch).toISOString() > moment(b?.timeSearch).toISOString()) return -1;
      if (moment(a?.timeSearch).toISOString() < moment(b?.timeSearch).toISOString()) return 1;
      return 0;
    });
    if (listSearch.length > 50) {
      listSearch = listSearch.slice(0, 50);
    }
    setAllTypeSearchHistory(listSearch);
  }, [searchHistory]);

  const handleDeleteSearch = (item: any) => {
    const newHistory = allTypeSearchHistory?.filter((h: any) => h.id !== item.id && item.type === h.type);
    updateSearchHistoryByType(item.type, newHistory);
    setAllTypeSearchHistory(newHistory);
    // setSearchHistory((prev) => prev?.filter((item) => item?.name !== name));
  };

  return (
    <div className="flex items-center justify-center w-full ">
      <div className="max-h-[387px] h-[calc(100vh_-_387px)] w-[295px]  bg-white rounded-[10px] px-[20px] py-[30px]">
        {!allTypeSearchHistory?.length ? (
          <div className="overflow-auto w-full h-full">
            <div className=" flex flex-col items-center justify-center text-center text-[15px] leading-[21px] font-semibold text-[#111111]">
              검색 기록이 남아 있지 않습니다.
              <br /> 🛬어떤 여행을 검색해 보시겠어요?
            </div>
            <div className=" mt-[15px] flex flex-col items-center justify-center space-y-[12px]">
              <Link
                className="h-[44px] bg-[#F5F6F6] rounded-[5px] w-full flex items-center justify-between px-[24px]"
                href="/package/overseas"
              >
                <span className="text-[14px] text-[#111111] leading-[16px] font-semibold">해외여행 알아보기</span>
                <Image alt="" height={18} src="/icons/radialMenu/searchHistory/icon_arrow_dark_18.svg" width={18} />
              </Link>
              <Link
                className="h-[44px] bg-[#F5F6F6] rounded-[5px] w-full flex items-center justify-between px-[24px]"
                href="/package/domestic"
              >
                <span className="text-[14px] text-[#111111] leading-[16px] font-semibold"> 국내여행 알아보기</span>
                <Image alt="" height={18} src="/icons/radialMenu/searchHistory/icon_arrow_dark_18.svg" width={18} />
              </Link>
              <Link
                className="h-[44px] bg-[#F5F6F6] rounded-[5px] w-full flex items-center justify-between px-[24px]"
                href="/flights"
              >
                <span className="text-[14px] text-[#111111] leading-[16px] font-semibold">항공 알아보기</span>
                <Image alt="" height={18} src="/icons/radialMenu/searchHistory/icon_arrow_dark_18.svg" width={18} />
              </Link>
              <Link
                className="h-[44px] bg-[#F5F6F6] rounded-[5px] w-full flex items-center justify-between px-[24px]"
                href="/hotel"
              >
                <span className="text-[14px] text-[#111111] leading-[16px] font-semibold">호텔 알아보기</span>
                <Image alt="" height={18} src="/icons/radialMenu/searchHistory/icon_arrow_dark_18.svg" width={18} />
              </Link>
              <Link
                className="h-[44px] bg-[#F5F6F6] rounded-[5px] w-full flex items-center justify-between px-[24px]"
                href="/special-exhibition"
              >
                <span className="text-[14px] text-[#111111] leading-[16px] font-semibold">기획전 알아보기</span>
                <Image alt="" height={18} src="/icons/radialMenu/searchHistory/icon_arrow_dark_18.svg" width={18} />
              </Link>
            </div>
          </div>
        ) : (
          <div className="flex flex-col justify-between h-full w-full">
            <div className="flex-1 flex flex-col overflow-auto !relative w-full space-y-3">
              {customMapUseIndex(allTypeSearchHistory as any[], ({ key, value }) => (
                <InformationSearch data={value} handleDeleteSearch={handleDeleteSearch} key={key} />
              ))}
              <div className=" sticky bottom-0 w-full h-[50px] bg-gradient-to-t from-white " />
            </div>

            <BasicButton
              className="!w-full"
              onClick={() => showPopUp(PopUp, { title: '최근검색', content: <RecentSearchMain /> })}
            >
              전체 보기
            </BasicButton>
          </div>
        )}
      </div>
    </div>
  );
}

export default SearchHistory;
