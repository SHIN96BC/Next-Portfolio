import { resizeImage } from 'common/presentation/components/common/ResizeImage';
import formatNumber from 'common/utils/formatNumber';
import Image from 'next/image';
import Link from 'next/link';
import { ReactNode } from 'react';

interface ProductType {
  type: 'hotel' | 'package' | 'localTour';
  price: string | number | null;
  date: string | ReactNode;
  title: string;
  image: string;
  isDomestic?: boolean | null;
  cityName?: string;
  isIncentive?: boolean;
  isShowPrice?: boolean;
}
const ProductCard = ({
  type,
  price,
  date,
  title,
  image,
  isDomestic,
  cityName,
  isIncentive,
  isShowPrice,
}: ProductType) => {
  return (
    <div className="w-full flex items-center  justify-center">
      <div className=" w-[73.82%] min-h-[131px]  bg-white rounded-[10px] shadow-[0px_0px_6px_#111111] relative">
        <div className="my-[24px] px-[20px]">
          <div className="flex space-x-[16px]">
            <div className="relative w-[57px] h-[57px]">
              <Image alt="" className="rounded-[10px]" layout="fill" src={resizeImage(image, '114:114')} />
            </div>
            <div className="flex flex-col flex-1 space-y-2 ">
              <div className="w-full flex justify-between leading-[15px]  ">
                <div className="text-[13px] text-[#009C75] font-semibold ">
                  {type === 'package' && <span>{isDomestic ? '[국내여행]' : '[해외여행]'}</span>}
                  {type === 'hotel' && '[호텔]'}
                  {type === 'localTour' && '[투어/패스]'}
                  {cityName}
                </div>
              </div>
              <div className="text-[#111111] text-[14px] font-semibold leading-[17px] line-clamp-2">{title}</div>
            </div>
          </div>
          <div className=" flex items-center justify-between h-[19px]  mt-[12px]">
            <div className="text-[#888888]  text-[12px] leading-[19px]  h-[14px]">
              {type === 'package' && <span className="font-semibold">출발일 </span>}
              {type === 'hotel' && <span className="font-semibold">1박 평균요금</span>}
              {date}
            </div>
            {!isIncentive && !isShowPrice && Number(price || 0) > 0 && (
              <div className="text-[16px] font-bold leading-[19px] h-[19px] text-[#111111] ">
                {formatNumber(price)}
                <span className="text-[14px] font-normal">원 ~</span>
              </div>
            )}
          </div>
        </div>
        <div className="absolute  leading-[17px] top-[-29px]">
          <div className=" text-[#fff] [&>a]:!text-[13px] [&>a]:!leading-[17px] [&>a]:inline-block [&>a:active]:!text-[#fff] [&>a:hover]:!text-[#fff]">
            <Link href="/my-page/wished-product">💗찜한 상품 비교하러 가기</Link>
            <div className="border-t-[1px] border-[#fff] pt-[1px]" />
          </div>
        </div>
      </div>
    </div>
  );
};
ProductCard.defaultProps = {
  isDomestic: false,
  cityName: '',
  isIncentive: false,
  isShowPrice: false,
};
export default ProductCard;
