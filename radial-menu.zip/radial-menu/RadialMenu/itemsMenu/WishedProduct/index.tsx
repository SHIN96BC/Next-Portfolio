import BasicButton from 'common/presentation/components/buttons/BasicButton';
import React, { useEffect, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation } from 'swiper';
import { RootState, useSelector } from 'common/redux/store';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import { useGetUserGetFavoritesQuery } from '@endpoints/user2';
import useLoginPopUpButton from 'common/presentation/components/auth/useLoginPopUpButton';
import { Skeleton } from 'antd';
import moment from 'moment';
import CardItem from '../CardItem';

import styles from '../../../../../styles/radialMenu/itemsMenu.module.scss';
import 'swiper/css';
import 'swiper/css/navigation';
import ProductCard from './ProductCard';

function WishedProduct() {
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const { data: wishedData, isFetching } = useGetUserGetFavoritesQuery({ type: undefined }, { skip: !accessToken });
  const [haveData, setHaveData] = useState<boolean>(false);
  const [loginFC] = useLoginPopUpButton();
  useEffect(() => {
    if (wishedData) {
      if (
        Number(wishedData.result?.hotels?.length ?? 0) +
          Number(wishedData.result?.products?.length ?? 0) +
          Number(wishedData.result?.localTours?.length ?? 0) >
        0
      ) {
        setHaveData(true);
      } else {
        setHaveData(false);
      }
    }
  }, [wishedData]);

  return (
    <>
      <div className="w-full flex items-center justify-center ">
        {!accessToken && (
          <CardItem
            content={
              <div className="h-[167px] flex items-center justify-center text-[#AAAAAA] text-[15px] font-medium  flex-col">
                <div className="text-[#111111] font-semibold text-[15px] leading-[21px] text-center mb-[24px]">
                  로그인 하시면 M다이얼에서 <br /> 찜한 상품을 바로 확인 할 수 있어요.
                </div>
                <BasicButton className="!w-full" onClick={() => loginFC()}>
                  로그인 하기
                </BasicButton>
              </div>
            }
          />
        )}
        {accessToken && !haveData && isFetching && (
          <div className="w-full flex justify-center items-center">
            <CardItem
              content={
                // <div className="min-h-[136px] flex items-center justify-center text-[#AAAAAA] text-[15px] font-medium">
                //   찜한 상품이 없습니다.
                // </div>
                <Skeleton
                  active
                  avatar
                  className="py-5 rounded-[20px] bg-[#fff]"
                  paragraph={{
                    rows: 2,
                  }}
                />
              }
            />
          </div>
        )}
      </div>
      {haveData && accessToken && (
        <div className={styles.customeNavigation}>
          <Swiper centeredSlides centeredSlidesBounds className="mySwiper" modules={[Navigation]} navigation>
            {wishedData?.result?.products &&
              wishedData?.result?.products.length > 0 &&
              wishedData?.result?.products.map((item) => (
                <SwiperSlide key={item.productNo}>
                  <ProductCard
                    cityName={item?.representativeCity ?? ''}
                    date={item.departureDate ?? ''}
                    image={item.image ?? ''}
                    isDomestic={item.isDomestic}
                    isIncentive={item.isIncentive ?? false}
                    isShowPrice
                    price={Number(item?.salePriceAdult ?? 0) + Number(item.fuelSurchargeAdult ?? 0)}
                    title={item.packageName ?? ''}
                    type="package"
                  />
                </SwiperSlide>
              ))}
            {wishedData?.result?.hotels &&
              wishedData?.result?.hotels.length > 0 &&
              wishedData?.result?.hotels.map((item) => (
                <SwiperSlide key={item.hotelNumber}>
                  <ProductCard
                    cityName=""
                    date=""
                    image={item.image ?? ''}
                    price={item.minPrice ?? 0}
                    title={item.hotelName ?? ''}
                    type="hotel"
                  />
                </SwiperSlide>
              ))}
            {wishedData?.result?.localTours &&
              wishedData?.result?.localTours.length > 0 &&
              wishedData?.result?.localTours.map((item) => (
                <SwiperSlide key={item.itemCode}>
                  <ProductCard
                    cityName={item?.cityName ?? ''}
                    date={
                      item?.createdAt ? (
                        <span className="text-[#888888]">·{moment(item?.createdAt).format('YYYY.MM.DD(dd)')}</span>
                      ) : (
                        ''
                      )
                    }
                    image={item.image ?? ''}
                    price={item.salesPrice ?? 0}
                    title={item.itemName ?? ''}
                    type="localTour"
                  />
                </SwiperSlide>
              ))}
          </Swiper>
        </div>
      )}
    </>
  );
}

export default WishedProduct;
