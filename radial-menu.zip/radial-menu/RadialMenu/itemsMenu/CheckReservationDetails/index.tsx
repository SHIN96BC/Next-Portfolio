import React from 'react';
import BasicButton from 'common/presentation/components/buttons/BasicButton';
import { Spin } from 'antd';
import { useRouter } from 'next/router';
import formatNumber from 'common/utils/formatNumber';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation } from 'swiper';
import useLoginPopUpButton from 'common/presentation/components/auth/useLoginPopUpButton';
import { RootState, useSelector } from 'common/redux/store';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import { ReservationJoinModel, useGetUserGetReservationsQuery } from '@endpoints/user2';
import { formatDate } from 'common/utils/main-page';
import {
  handleGetDiscountFlightPeople,
  handleGetFlightPeople,
  handleGetHotelPeople,
  handleGetPackagePeople,
  handleGetTourPassPeople,
} from 'common/utils/my-page';
import { AllowedReservationTypes, makeDetectTypeReservation, ReservationTypes } from 'common/modules/core';
import CardItem from '../CardItem';
import styles from '../../../../../styles/radialMenu/itemsMenu.module.scss';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';

const Tag = ({ value, type }: { value: JSX.Element | string; type: number }) => {
  if ((value as string).length === 0) return <div />;
  return (
    <span
      className={`rounded-[4px] text-[11px] font-semibold leading-[21px] text-center px-[7px] h-[24px]
      ${type === 1 && 'text-[#0075E9] border-[#0075E9] border'} 
      ${type === 2 && 'text-[#FFFFFF] bg-[#8F9F9B]'}
      ${type === 3 && 'text-[#FFFFFF] bg-[#47B896]'}
      ${type === 4 && 'text-[#FFFFFF] bg-[#475451]'}
      ${type === 5 && 'text-[#0075E9] border-[#0075E9] border'} 
      ${type === 6 && 'text-[#FFFFFF] bg-[#8F9F9B]'}
      ${type === 7 && 'text-[#FFFFFF] bg-[#47B896]'}
      ${type === 8 && 'text-[#FFFFFF] bg-[#475451]'}
      `}
    >
      {value}
    </span>
  );
};
export const TypeData: { [key: string]: string } = {
  DTravel: '국내여행',
  OTravel: '해외여행',
  Travel: '여행',
  DFlight: '국내항공',
  OFlight: '해외항공',
  DiscountFlight: '할인 항공권',
  Flight: '항공',
  DHotel: '국내호텔',
  OHotel: '해외호텔',
  Hotel: '호텔',
  LocalTour: '투어/패스',
};

export const HyPhen: React.FC = () => {
  return <span className="font-medium text-[14px] text-[#111111]"> - </span>;
};

function CheckReservationDetails() {
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const { data: reservationData, isFetching } = useGetUserGetReservationsQuery(
    {
      type: 'All',
      pageNo: 1,
      totalRecord: 10,
    },
    { skip: !accessToken }
  );
  const router = useRouter();

  const [loginFC] = useLoginPopUpButton();
  const handleClick = (
    productTypeName?: string | null,
    orderNo?: number,
    ptid?: number | string | null,
    accumulationExpectedTourMileage?: number | undefined | null
  ) => {
    if (!productTypeName) return;
    if (productTypeName === 'OFlight' || productTypeName === 'Flight') {
      router.push(`/my-page/reservation-history/flight/oversea?oId=${orderNo}&pId=${ptid}`);
      return;
    }
    if (productTypeName === 'DiscountFlight') {
      router.push(`/my-page/reservation-history/flight/discount-airlines?oId=${orderNo}&pId=${ptid}`);
      return;
    }
    if (productTypeName === 'DFlight') {
      router.push(`/my-page/reservation-history/flight/domestic?inum=${orderNo}&pid=${ptid}`);
      return;
    }
    if (productTypeName === 'Hotel' || productTypeName === 'DHotel' || productTypeName === 'OHotel') {
      router.push(
        `/my-page/reservation-history/hotel?oId=${orderNo}&accumulationExpectedTourMileage=${accumulationExpectedTourMileage}`
      );
      return;
    }
    if (productTypeName === 'LocalTour') {
      router.push(`/my-page/reservation-history/tour-pass-vehicle?oId=${orderNo}&pId=${ptid}`);
      return;
    }
    router.push(
      `/my-page/reservation-history/travel-detail/${orderNo}?typePackage=${
        productTypeName === 'DTravel' ? 'domestic' : 'overseas'
      }`
    );
  };

  const getPeople = (code: AllowedReservationTypes, data: ReservationJoinModel): string => {
    const type = makeDetectTypeReservation().detectType(code);
    if (!type) {
      return '';
    }

    let amountPeople = '';
    if (type.name === ReservationTypes.DiscountFlight) {
      amountPeople = handleGetDiscountFlightPeople(data);
      return amountPeople;
    }

    switch (type.groupName) {
      case ReservationTypes.Flight:
        amountPeople = handleGetFlightPeople(data);
        break;
      case ReservationTypes.Hotel:
        amountPeople = handleGetHotelPeople(data);
        break;
      case ReservationTypes.Package:
        amountPeople = handleGetPackagePeople(data);
        break;
      case ReservationTypes.TourPass:
        amountPeople = handleGetTourPassPeople(data);
        break;
      default:
        break;
    }
    return amountPeople || '';
  };

  return (
    <div className={styles.customeNavigation}>
      <Spin spinning={isFetching}>
        {!isFetching && (
          <>
            {accessToken && reservationData?.result?.data && reservationData?.result?.data.length > 0 && (
              <Swiper centeredSlides centeredSlidesBounds className="mySwiper" modules={[Navigation]} navigation>
                {reservationData?.result?.data?.map(
                  ({
                    tags,
                    productName,
                    productType,
                    productTypeName,
                    arrivalDate,
                    departureDate,
                    peopleCount,
                    price,
                    orderNo,
                    reserveDeputyNo,
                    pidEnc,
                    accumulationExpectedTourMileage,
                    stateNameKorean,
                    flightInfo,
                    ...rest
                  }) => {
                    const amountOfPeople = getPeople((productType || productTypeName) as AllowedReservationTypes, rest);

                    return (
                      <SwiperSlide key={productName}>
                        <CardItem
                          content={
                            <div className="pt-[25px] pb-[22px] min-h-[213px]">
                              <div className="flex space-x-[8px] flex-wrap">
                                {tags?.split('#').map((item, index) => {
                                  if (item.length === 0 || index > 7) return null;
                                  return <Tag key={item} type={index} value={item} />;
                                })}
                              </div>
                              <div>
                                <div className="text-[#009C75] text-[13px] font-semibold leading-[19px] py-[8px]">
                                  {productTypeName && TypeData[productTypeName]}
                                </div>
                                <div className="text-[14px] text-[#111111] font-semibold leading-[18px] mb-[12px]">
                                  {productName}
                                </div>
                                <ul className="text-[12px]  font-medium text-[#888888] mb-[12px]">
                                  {productTypeName === 'OFlight' ||
                                  productTypeName === 'DFlight' ||
                                  productTypeName === 'Flight' ? (
                                    <li className="leading-[19px] mb-[4px] whitespace-pre-line">
                                      {flightInfo?.[0]?.seg?.map(
                                        (segItem) => `${segItem?.dlcn} - ${segItem?.alcn} : ${segItem?.ddt} \n`
                                      )}
                                    </li>
                                  ) : (
                                    <li className="leading-[19px] mb-[4px]">
                                      {formatDate(departureDate as string)} ~ {formatDate(arrivalDate as string)}
                                    </li>
                                  )}
                                  {amountOfPeople ? (
                                    <li className="leading-[19px] h-[14px]">
                                      · {getPeople((productType || productTypeName) as AllowedReservationTypes, rest)}
                                    </li>
                                  ) : (
                                    <HyPhen />
                                  )}
                                  {stateNameKorean && <li className="leading-[19px] h-[14px]">· {stateNameKorean}</li>}
                                </ul>
                                <div className="text-right font-bold text-[16px] text-[#111111]">
                                  {!!price && !!parseInt(`${price}`, 10) ? (
                                    <>
                                      {formatNumber(price)}
                                      <span className="font-medium text-[14px]">원 ~</span>
                                    </>
                                  ) : (
                                    <HyPhen />
                                  )}
                                </div>
                              </div>
                            </div>
                          }
                          handleAction={() => {
                            handleClick(
                              productTypeName,
                              orderNo,
                              pidEnc || reserveDeputyNo,
                              accumulationExpectedTourMileage
                            );
                          }}
                        />
                      </SwiperSlide>
                    );
                  }
                )}
              </Swiper>
            )}

            {accessToken && (!reservationData?.result?.data || reservationData?.result?.data.length === 0) && (
              <div className="w-full flex justify-center items-center">
                <CardItem
                  content={
                    <div className="py-[20px] flex flex-col items-center justify-center text-[#AAAAAA] font-medium">
                      <span className="mb-[16px]">예약내역이 없습니다.</span>
                      <BasicButton
                        onClick={() => {
                          router.push('/my-page/reservation-history');
                        }}
                      >
                        확인
                      </BasicButton>
                    </div>
                  }
                />
              </div>
            )}
            {!accessToken && (
              <div className="w-full flex justify-center items-center">
                <CardItem
                  content={
                    <div className="h-full w-full flex flex-col items-center">
                      <div className=" h-[219px] w-full pt-[30px] pb-[20px]">
                        <div className="mb-[20px] text-[#111111] font-semibold text-center text-[15px] leading-[21px]">
                          로그인 하시면 M다이얼에서
                          <br /> 예약내역을 바로 확인 할 수 있어요.
                        </div>
                        <BasicButton className="!w-full !min-h-[44px]" onClick={() => loginFC()}>
                          로그인하기
                        </BasicButton>
                        <BasicButton
                          className="!w-full mt-[12px] !min-h-[44px]"
                          onClick={() =>
                            router.push({ pathname: '/my-page/non-member/reservation-confirmation-payment' })
                          }
                          type="outline"
                        >
                          비회원 예약조회
                        </BasicButton>
                      </div>
                    </div>
                  }
                />
              </div>
            )}
          </>
        )}
      </Spin>
    </div>
  );
}

export default CheckReservationDetails;
