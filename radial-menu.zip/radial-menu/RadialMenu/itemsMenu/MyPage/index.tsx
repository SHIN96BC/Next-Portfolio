import useLoginPopUpButton from 'common/presentation/components/auth/useLoginPopUpButton';
import BasicButton from 'common/presentation/components/buttons/BasicButton';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import { RootState, useSelector } from 'common/redux/store';
import { useRouter } from 'next/router';
import React from 'react';
import CardItem from '../CardItem';

function MyPage() {
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const [loginFC] = useLoginPopUpButton();
  const router = useRouter();
  const handleClick = () => {
    if (accessToken) {
      router.push('/my-page');
    } else if (!accessToken) {
      loginFC();
    }
  };
  return (
    <div className="w-full flex items-center justify-center">
      <CardItem
        content={
          <div className="h-[167px] flex items-center justify-center text-[#AAAAAA] text-[15px] font-medium  flex-col">
            <div className="text-[#111111] font-semibold text-[15px] leading-[21px] text-center mb-[24px]">
              내가 이용한 모두투어의 정보가
              <br /> 모두 여기에~😮
            </div>
            <BasicButton className="!w-full" onClick={handleClick}>
              {accessToken ? '바로 가기' : '로그인 하기'}
            </BasicButton>
          </div>
        }
      />
    </div>
  );
}

export default MyPage;
