import { Skeleton } from 'antd';
import { usePostUserGetRecentlyViewedQuery } from '@endpoints/user2';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import { TokenUser } from 'common/redux/slices/tokenNotLogin.slice';
import { RootState, useSelector } from 'common/redux/store';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Navigation } from 'swiper';
import { Swiper, SwiperSlide } from 'swiper/react';

import PopUp from 'common/presentation/components/common/PopUp';
import { usePopUp } from 'common/presentation/components/pop-ups/provider';
import 'swiper/css';
import 'swiper/css/navigation';
import styles from '../../../../../styles/radialMenu/itemsMenu.module.scss';
import { useOnScreen } from '../../../../../utils/useOnScreen';
import CardItem from '../CardItem';
import RecentlyProductAll from './RecentlyProductAll';
import { ProductType } from './RecentlyProductAll/type';
import RecentlyProductCard from './RecentlyProductCard';

function RecentlyViewed() {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useOnScreen(ref);
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const { tokenNotLogin } = useSelector<RootState, TokenUser>((state) => state.tokenNotLogin);
  const { data, isFetching, refetch } = usePostUserGetRecentlyViewedQuery(
    {
      recentlyViewedRequest: {
        userIdentifier: accessToken ? '' : tokenNotLogin,
      },
    },
    { refetchOnMountOrArgChange: true }
  );

  const { showPopUp } = usePopUp();
  const [dataRecently, setDataRecently] = useState<ProductType[]>([]);
  const [dataRecentlySort, setDataRecentlySort] = useState<ProductType[]>([]);

  // const getTime = (timeIn: string, timeOut: string) => {
  //   const timeInMoment = moment(timeIn);
  //   const timeOutMoment = moment(timeOut);
  //   const timeDiff = timeOutMoment.diff(timeInMoment, 'days');
  //   return `(${timeDiff - 1}박${timeDiff}일)`;
  // };

  useEffect(() => {
    let product: ProductType[] = [];
    let airline: ProductType[] = [];
    let localTour: ProductType[] = [];
    let hotel: ProductType[] = [];
    if (data?.result) {
      if (data.result?.productList && data.result?.productList.length > 0) {
        product = data.result?.productList.map((item) => ({
          image: item.image ?? '',
          type: 'Product',
          title: item.packageName ?? '',
          name: item.groupRegionName ?? '',
          time: `${moment(item.departureDate).format('YYYY.MM.DD')}`,
          code: item.recentlyViewNo?.toString() ?? '',
          viewDate: `${moment(item.createdAt)}`,
          isDomestic: item.isDomestic ?? false,
          price: (item?.salePriceAdult ?? 0) + (item?.fuelSurchargeAdult ?? 0),
          // price: (parseInt(item?.salePriceAdult, 10) || 0) + (parseInt(item?.fuelSurchargeAdult, 10) || 0),
        }));
      }
      // if (data.result?.airList && data.result?.airList.length > 0) {
      //   airline = data.result?.airList.map((item, index: number) => ({
      //     image: '/images/main/icon_flight.png',
      //     type: 'Airline',
      //     title: `${item.rot === 'OW' ? '[편도]' : ''}${item.rot === 'RT' ? '[왕복]' : ''}${item.depatureAirportName}${
      //       item.rot === 'OW' ? ' -> ' : ''
      //     }${item.rot === 'RT' ? ' ↔ ' : ''}${item.destinationAirportName}`,
      //     time: `· ${moment(item.departureDate).format('YYYY.MM.DD(ddd)')} ~ ${moment(item.arrivalDate).format(
      //       'YYYY.MM.DD(ddd)'
      //     )}`,
      //     code: `air-${index}`,
      //     airlineCode: item.airlineCode ?? '',
      //     viewDate: `${moment(item.registerDate)}`,
      //   }));
      // }
      if (data.result?.hotelList && data.result?.hotelList.length > 0) {
        hotel = data.result?.hotelList.map((item) => ({
          image: item.image ?? '',
          type: 'Hotel',
          title: item.hotelName ?? '',
          time:
            // item.checkInDate && item.checkOutDate
            //   ? `·  ${moment(item.checkInDate).format('YYYY.MM.DD')}~${moment(item.checkOutDate).format(
            //       'YYYY.MM.DD'
            //     )}  ${getTime(item.checkInDate ?? '', item.checkOutDate ?? '')}`
            '',
          // name: item.cityName ?? '',
          name: '',
          code: item.recentlyViewNo?.toString() ?? '',
          viewDate: `${moment(item.createdAt)}`,
          price: item?.minPrice,
        }));
      }
      if (data.result?.localTourList && data.result?.localTourList.length > 0) {
        localTour = data.result?.localTourList.map((item) => ({
          image: item.image ?? '',
          type: 'LocalTour',
          title: item.itemName ?? '',
          time: item.createdAt ? `· ${moment(item.createdAt).format('YYYY.MM.DD(ddd)')}` : '',
          code: item.recentlyViewNo?.toString() ?? '',
          name: item.cityName,
          viewDate: `${moment(item.createdAt)}`,
          price: item?.salesPrice,
        }));
      }
      setDataRecently([...product, ...airline, ...hotel, ...localTour]);
      product = [];
      airline = [];
      hotel = [];
      localTour = [];
    } else {
      setDataRecently([]);
    }
  }, [data?.result]);

  useEffect(() => {
    if (dataRecently && dataRecently.length > 0) {
      const dataSort = dataRecently.sort((a, b) => moment(b.viewDate).diff(moment(a.viewDate)));
      setDataRecentlySort(dataSort);
    } else {
      setDataRecentlySort([]);
    }
  }, [dataRecently]);

  useEffect(() => {
    if (isVisible) {
      refetch();
    }
  }, [isVisible]);
  return (
    <div className={styles.customeNavigation} ref={ref}>
      {isFetching && (
        <Skeleton
          active
          className="p-5 rounded-[20px] bg-[#fff]"
          paragraph={{
            rows: 2,
          }}
        />
      )}
      {!isFetching && (
        <div>
          {dataRecentlySort?.length === 0 && (
            <div
              className="w-full flex justify-center items-center cursor-pointer"
              onClick={() =>
                showPopUp(PopUp, {
                  title: <div className="text-[20px] text-[#111] font-bold">최근 본 상품</div>,
                  content: <RecentlyProductAll />,
                  spaceBottom: '20px',
                  isTopSpace: false,
                })
              }
              role="presentation"
            >
              <CardItem
                content={
                  <div className="min-h-[136px] flex items-center justify-center text-[#AAAAAA] text-[15px] font-medium">
                    최근 본 상품이 없습니다.
                  </div>
                }
              />
            </div>
          )}
          {dataRecentlySort?.length > 0 && (
            <Swiper centeredSlides centeredSlidesBounds className="mySwiper" modules={[Navigation]} navigation>
              {dataRecentlySort.map((item) => (
                <SwiperSlide key={item.code}>
                  <RecentlyProductCard
                    codeAirline={item.airlineCode}
                    image={item.image}
                    isDomestic={item?.isDomestic}
                    name={item.name}
                    price={item.price}
                    time={item.time}
                    title={item.title}
                    type={item.type}
                    viewDate={moment(item.viewDate).format('YYYY.MM.DD')}
                  />
                </SwiperSlide>
              ))}
            </Swiper>
          )}
        </div>
      )}
    </div>
  );
}

export default RecentlyViewed;
