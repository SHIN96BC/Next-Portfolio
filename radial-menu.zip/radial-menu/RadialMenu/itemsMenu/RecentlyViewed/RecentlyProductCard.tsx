import { AirlineIcon } from 'common/presentation/components/common/AirlineIcon';
import PopUp from 'common/presentation/components/common/PopUp';
import { resizeImage } from 'common/presentation/components/common/ResizeImage';
import { usePopUp } from 'common/presentation/components/pop-ups/provider';
import formatNumber from 'common/utils/formatNumber';
import moment from 'moment';
import Image from 'next/image';
import CardItem from '../CardItem';
import RecentlyProductAll from './RecentlyProductAll';

interface RecentlyProductType {
  image: string;
  type: 'Product' | 'Hotel' | 'LocalTour' | 'Airline';
  codeAirline: string | undefined;
  viewDate: string;
  title: string;
  time: string;
  price: number | undefined | string | null;
  isDomestic: boolean | null | undefined;
  name: string | null | undefined;
}
const RecentlyProductCard = ({
  image,
  type,
  codeAirline,
  viewDate,
  title,
  time,
  price,
  isDomestic,
  name,
}: RecentlyProductType) => {
  const today = moment();
  const { showPopUp } = usePopUp();
  const diffInDays = today.diff(viewDate, 'days');
  return (
    <div
      className="w-full flex items-center justify-center"
      onClick={() => {
        showPopUp(PopUp, {
          title: <div className="text-[20px] text-[#111] font-bold">최근 본 상품</div>,
          content: <RecentlyProductAll />,
          spaceBottom: '20px',
          isTopSpace: false,
        });
      }}
      role="presentation"
    >
      <CardItem
        content={
          <div className="my-[24px]">
            <div className="flex space-x-[16px]">
              <div className="relative w-[57px] h-[57px]">
                <Image alt="" className="rounded-[10px]" layout="fill" src={resizeImage(image, '114:114')} />
              </div>
              <div className="flex flex-col flex-1 space-y-[8px] ">
                <div className="w-full flex justify-between leading-[14px] items-start ">
                  <div className="text-[13px] text-[#009C75] font-semibold">
                    {type === 'Product' && (isDomestic ? '[국내여행]' : '[해외여행]')}
                    {type === 'Airline' && (
                      <div className="flex items-center space-x-[8px]">
                        <div>[항공]</div>
                        <AirlineIcon airlineCode={codeAirline?.toLowerCase() ?? ''} size={15} />
                      </div>
                    )}
                    {type === 'Hotel' && '[호텔]'}
                    {type === 'LocalTour' && '[투어/패스]'}
                    {name ?? ''}
                  </div>
                  {!Number.isNaN(diffInDays) && (
                    <div className="text-[11px] text-[#AAAAAA] font-normal  leading-[13px] break-keep">
                      {diffInDays === 0 ? '오늘' : `${diffInDays}일전`}
                    </div>
                  )}
                </div>
                <div className="text-[#111111] text-[14px] font-semibold leading-[17px] line-clamp-2">{title}</div>
              </div>
            </div>
            <div className=" flex items-center justify-between  mt-[12px]">
              <div className="text-[#888888]  text-[12px] leading-[19px]  h-[14px]">
                {type !== 'Hotel' && time && (
                  <div className="text-[#888888] text-[12px] leading-[19px] h-[26px]">
                    {type === 'Product' && <span className="font-semibold">출발일 </span>}
                    {time}
                  </div>
                )}
                {type === 'Hotel' && (
                  <div className="text-[#888888] text-[12px] leading-[19px] h-[26px]">
                    <span className="font-semibold">1박 평균요금</span>
                  </div>
                )}
              </div>
              {price !== '0' && price !== 0 && (
                <div className="text-[#111111] text-[16px] leading-[19px] h-[19px] font-bold">
                  {formatNumber(price)}
                  <span className="text-[14px] font-normal">원</span>
                </div>
              )}
            </div>
          </div>
        }
      />
    </div>
  );
};

export default RecentlyProductCard;
