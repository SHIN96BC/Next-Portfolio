export interface ProductType {
  image: string;
  type: 'Hotel' | 'Product' | 'LocalTour' | 'Airline';
  airlineCode?: string;
  title: string;
  time: string;
  code: string;
  viewDate: string;
  isDomestic?: boolean | null | undefined;
  price?: number | string | undefined | null;
  id?: number | string | null;
  dataSearchHotel?: {
    countryCode?: string | null | undefined;
    cityCode?: string | null | undefined;
    checkInDate?: string;
    checkOutDate?: string;
    numberOfRoom?: number;
    numberOfAdult?: number;
    numberOfChild?: number;
    adultArray?: string;
    childArray?: string;
    childAgeArray?: string;
    peopleAndRoom?: {
      id: number;
      room?: number | null | undefined;
      adult?: number | null | undefined;
      child?: number | null | undefined;
      ageChilds?: number[] | null;
    }[];
  };
  name?: string | null;
}

export interface ProductSort {
  viewDate: string;
  product: ProductType[];
}
