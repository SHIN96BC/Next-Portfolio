import { useAlert } from 'common/presentation/components/common/Alert/hooks';
import SpinBase from 'common/presentation/components/SpinBase';
import { usePostUserDeleteRecentlyViewedMutation } from '@endpoints/user2';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import { TokenUser } from 'common/redux/slices/tokenNotLogin.slice';
import { RootState, useSelector } from 'common/redux/store';
import customMapUseIndex from 'common/utils/customMapUseIndex';
import moment from 'moment';
import React, { useEffect } from 'react';
import { ProductSort, ProductType } from '../type';
import ProductInfo from './ProductInfo';

interface DataProps {
  dataRecently: ProductSort[];
  refetch: () => void;
  isLoading: boolean;
}

const ProductAll = ({ dataRecently, refetch, isLoading }: DataProps) => {
  const today = moment();
  const [trigger, { isSuccess }] = usePostUserDeleteRecentlyViewedMutation();
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const { tokenNotLogin } = useSelector<RootState, TokenUser>((state) => state.tokenNotLogin);
  const { openAlert } = useAlert();
  let sum = 0;
  dataRecently.forEach((item) => {
    item.product.sort((a, b) => {
      const momentA = moment(a.viewDate);
      const momentB = moment(b.viewDate);
      return momentB.diff(momentA);
    });
  });

  const deleteAll = (data: ProductType[]) => {
    let itemProduct = data.filter((item) => item.type === 'Product').map((productId) => Number(productId.code));
    let itemHotel = data.filter((item) => item.type === 'Hotel').map((productId) => Number(productId.code));
    let itemLocalTour = data.filter((item) => item.type === 'LocalTour').map((productId) => Number(productId.code));

    if (data.length > 0) {
      openAlert({
        message: (
          <div className="flex flex-col items-center justify-center w-full h-full px-[60px] text-center">
            최근 본 여행상품 목록을 모두 삭제하시겠습니까?
          </div>
        ),
        onOk: () => {
          if (itemProduct.length > 0) {
            trigger({
              deleteRecentlyViewedRequest: {
                type: 'Product',
                recentlyViewNos: [...itemProduct],
                userIdentifier: accessToken ? '' : tokenNotLogin,
              },
            });
            itemProduct = [];
          }
          if (itemHotel.length > 0) {
            trigger({
              deleteRecentlyViewedRequest: {
                type: 'Hotel',
                recentlyViewNos: [...itemHotel],
                userIdentifier: accessToken ? '' : tokenNotLogin,
              },
            });
            itemHotel = [];
          }
          if (itemLocalTour.length > 0) {
            trigger({
              deleteRecentlyViewedRequest: {
                type: 'LocalTour',
                recentlyViewNos: [...itemLocalTour],
                userIdentifier: accessToken ? '' : tokenNotLogin,
              },
            });
            itemLocalTour = [];
          }
        },
      });
    }
  };
  useEffect(() => {
    if (isSuccess) {
      refetch();
    }
  }, [isSuccess]);

  const renderProduct = (item: ProductType) => {
    sum += 1;
    return sum <= 50 ? (
      <div className="py-[24px]" key={item.code}>
        <ProductInfo
          airlineCode={item.airlineCode}
          code={item.code}
          dataSearchHotel={item.dataSearchHotel}
          id={item.id}
          image={item.image}
          isDomestic={item.isDomestic}
          price={item.price}
          refetch={refetch}
          time={item.time}
          title={item.title}
          type={item.type}
          viewDate={moment(item.viewDate).format('YYYY.MM.DD')}
        />
      </div>
    ) : null;
  };
  return (
    <SpinBase loading={isLoading}>
      <div className="divide-y-[8px] divide-[#EEEEEE] [&>div:last-child]:pb-[0px] pb-[60px] ">
        {customMapUseIndex(dataRecently, ({ key, value }) => (
          <div>
            {sum < 50 ? (
              <div className="pt-[30px] pb-[24px]" key={key}>
                <div className="text-[#111] flex items-center justify-between mx-[20px]">
                  <div className="font-bold leading-[19px] text-[16px]">
                    {today.diff(moment(value.viewDate), 'days') === 0
                      ? '오늘'
                      : moment(value.viewDate).format('YYYY.MM.DD')}
                  </div>
                  <div
                    className="text-[12px] font-medium leading-[14px] underline underline-offset-2 text-[#AAAAAA] cursor-pointer"
                    onClick={() => deleteAll(value.product)}
                    role="presentation"
                  >
                    전체삭제
                  </div>
                </div>
                <div className="divide-y-[1px] divide-[#E0E0E0]  [&>div:last-child]:pb-[0px] ">
                  {value?.product?.map((item) => renderProduct(item))}
                </div>
              </div>
            ) : null}
          </div>
        ))}
      </div>
    </SpinBase>
  );
};

export default ProductAll;
