import React, { useEffect } from 'react';
import Image from 'next/image';
import { Image as ImageAnt } from 'antd';
import { usePostUserDeleteRecentlyViewedMutation } from '@endpoints/user2';
import { RootState, useSelector } from 'common/redux/store';
import { TokenUser } from 'common/redux/slices/tokenNotLogin.slice';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import formatNumber from 'common/utils/formatNumber';
import { useRouter } from 'next/router';
import { PeopleAndRoomProps, SearchHotelType } from 'common/types/hotels/type';
import moment from 'moment';
import { AirlineIcon } from 'common/presentation/components/common/AirlineIcon';
import { useAlert } from 'common/presentation/components/common/Alert/hooks';
import { ProductType } from '../type';

interface RefetchType {
  refetch: () => void;
}

type ProductInfoProps = ProductType & RefetchType;

const ProductInfo = ({
  image,
  type,
  airlineCode,
  title,
  time,
  code,
  refetch,
  isDomestic,
  price,
  id,
}: ProductInfoProps) => {
  const [trigger, { isSuccess }] = usePostUserDeleteRecentlyViewedMutation();
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const { tokenNotLogin } = useSelector<RootState, TokenUser>((state) => state.tokenNotLogin);
  const { dataSearchHotel } = useSelector((state: { searchHotel: SearchHotelType }) => state.searchHotel);
  const router = useRouter();
  const { openAlert } = useAlert();

  const handleDelete = () => {
    openAlert({
      message: (
        <div className="flex flex-col items-center justify-center w-full h-full px-[60px] text-center">
          삭제하시 겠습니까?
        </div>
      ),
      onOk: () => {
        if (type !== 'Airline') {
          trigger({
            deleteRecentlyViewedRequest: {
              type: type,
              recentlyViewNos: [Number(code)],
              userIdentifier: accessToken ? '' : tokenNotLogin,
            },
          });
        }
      },
    });
  };
  useEffect(() => {
    if (isSuccess) {
      refetch();
    }
  }, [isSuccess]);

  const handleToSeeDetails = () => {
    if (type === 'Product') {
      router.push(`/package/${id}?type=${isDomestic ? 'domestic' : 'overseas'}`);
    }
    if (type === 'LocalTour') {
      router.push({ pathname: `/tour-pass-vehicle/${id}`, query: { maxProduct: 10 } });
    }
    if (type === 'Hotel') {
      const queryData = {
        hotelCode: id,
        countryCode: 'VN',
        cityCode: '3479',
        price: price === 0 || price === null || price === undefined ? Number(price) : 123456,
        basicPrice: price === 0 || price === null || price === undefined ? Number(price) : 123456,
        checkInDate: moment(dataSearchHotel.dateStay.startDate).format('YYYY-MM-DD'),
        checkOutDate: moment(dataSearchHotel.dateStay.endDate).format('YYYY-MM-DD'),
        numberOfRoom: dataSearchHotel?.peopleAndRoom?.length || 1,
        numberOfAdult:
          dataSearchHotel?.peopleAndRoom?.reduce((a: number, b: PeopleAndRoomProps) => a + b.adult, 0) || 1,
        numberOfChild:
          dataSearchHotel?.peopleAndRoom?.reduce((a: number, b: PeopleAndRoomProps) => a + b.child, 0) || 0,
        adultArray: dataSearchHotel.peopleAndRoom?.map((a: PeopleAndRoomProps) => a.adult).join(','),
        childArray: dataSearchHotel.peopleAndRoom?.map((a: PeopleAndRoomProps) => a.child).join(','),
        childAgeArray: dataSearchHotel?.peopleAndRoom
          ?.map((a: any) => a.ageChilds)
          ?.flatMap((row: any, rowIndex: number) =>
            row?.filter((valueA: any) => valueA !== null).map((valueA: any) => `${rowIndex}^${valueA}`)
          )
          .join(','),
        queryDataSearch: dataSearchHotel,
      };

      router.push({
        pathname: `/hotel/${isDomestic ? 'domestic' : 'overseas'}/${id}`,
        query: {
          type: JSON.stringify(isDomestic ? 'domestic' : 'overseas'),
          query: JSON.stringify(queryData),
        },
      });
    }
  };
  return (
    <div className="px-[20px] flex space-x-6">
      <div className="relative w-[100px] h-[100px]">
        <Image alt="" className="rounded-[10px]" layout="fill" src={image} />
      </div>
      <div className="flex-1 flex">
        <div className="flex justify-between flex-col flex-1">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="font-semibold leading-[19px] h-[16px] text-[#009C75]">
                {type === 'Product' && <div>{isDomestic ? '[국내여행]' : '[해외여행]'}</div>}
                {type === 'Airline' && (
                  <div className="flex items-center space-x-[10px]">
                    <div>[항공]</div>
                    <AirlineIcon airlineCode={airlineCode?.toLowerCase() ?? ''} size={15} />
                  </div>
                )}
                {type === 'Hotel' && '[호텔]'}
                {type === 'LocalTour' && '[투어/패스]'}
              </div>
              <div className="w-[14px] h-[14px] cursor-pointer" onClick={handleDelete} role="presentation">
                <ImageAnt alt="icon_delete" preview={false} src="/icons/icon_x_14.svg" />
              </div>
            </div>
            <div
              className="text-[15px] font-semibold leading-[18.5px] line-clamp-2 cursor-pointer"
              onClick={handleToSeeDetails}
              role="presentation"
            >
              {title}
            </div>
          </div>
          {type === 'Product' && (
            <div className={`flex ${price && time ? 'justify-between items-center' : 'justify-start'}`}>
              {time && (
                <div className="text-[12px] leading-[19px] h-[15px] text-[#888888] flex space-x-[4px]">
                  <div className="font-semibold">출발일</div>
                  <div>{time}</div>
                </div>
              )}
              {price !== 0 && price !== '0' && (
                <div className="text-[16px] font-bold leading-[19px] h-[19px] text-[#111111] ">
                  {formatNumber(price)}
                  <span className="text-[14px] font-normal">원</span>
                </div>
              )}
            </div>
          )}
          {type === 'Hotel' && (
            <div className="flex justify-between items-center">
              <div className="text-[12px] leading-[19px] h-[15px] text-[#888888] flex space-x-[4px]">
                <div className="font-semibold">1박 평균요금 </div>
              </div>
              {price !== 0 && price !== '0' && (
                <div className="text-[16px] font-bold leading-[19px] h-[19px] text-[#111111] ">
                  {formatNumber(price)}
                  <span className="text-[14px] font-normal">원</span>
                </div>
              )}
            </div>
          )}
          {type === 'LocalTour' && (
            <div className="flex justify-between items-center">
              <div className="text-[12px] leading-[19px] h-[15px] text-[#888888] flex space-x-[4px]">
                <div className="font-semibold">{time}</div>
              </div>
              {price !== 0 && price !== '0' && (
                <div className="text-[16px] font-bold leading-[19px] h-[19px] text-[#111111] ">
                  {formatNumber(price)}
                  <span className="text-[14px] font-normal">원</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductInfo;
