import { Skeleton } from 'antd';
import { usePostUserGetRecentlyViewedQuery } from '@endpoints/user2';
import { AuthSliceShape } from 'common/redux/slices/auth.slide';
import { TokenUser } from 'common/redux/slices/tokenNotLogin.slice';
import { RootState, useSelector } from 'common/redux/store';
import moment from 'moment';
import React, { useEffect, useState } from 'react';
import RecentSearchNoData from '../../../../../RecentSearchMain/RecentSearchNoData';
import ProductAll from './components/ProductAll';
import { ProductSort, ProductType } from './type';

const RecentlyProductAll = () => {
  const { accessToken } = useSelector<RootState, AuthSliceShape>((state) => state.auth);
  const { tokenNotLogin } = useSelector<RootState, TokenUser>((state) => state.tokenNotLogin);
  const { data, refetch, isFetching, isLoading } = usePostUserGetRecentlyViewedQuery({
    recentlyViewedRequest: { userIdentifier: accessToken ? '' : tokenNotLogin },
  });
  const [dataRecently, setDataRecently] = useState<ProductType[]>([]);
  const [dataRecentlySort, setDataRecentlySort] = useState<ProductSort[]>([]);

  useEffect(() => {
    let product: ProductType[] = [];
    let airline: ProductType[] = [];
    let localTour: ProductType[] = [];
    let hotel: ProductType[] = [];
    if (data?.result) {
      if (data.result?.productList && data.result?.productList.length > 0) {
        product = data.result?.productList.map((item) => ({
          image: item.image ?? '',
          type: 'Product',
          title: item.packageName ?? '',
          time: `${moment(item.departureDate).format('YYYY.MM.DD')}`,
          code: item.recentlyViewNo?.toString() ?? '',
          viewDate: `${moment(item.createdAt)}`,
          isDomestic: item.isDomestic ?? false,
          price: Number(item?.salePriceAdult ?? 0) + Number(item.fuelSurchargeAdult ?? 0),
          id: item.productNo,
        }));
      }

      if (data.result?.hotelList && data.result?.hotelList.length > 0) {
        hotel = data.result?.hotelList.map((item) => ({
          image: item?.image ?? '',
          type: 'Hotel',
          title: item.hotelName ?? '',
          time: '',
          code: item.recentlyViewNo?.toString() ?? '',
          viewDate: `${moment(item.createdAt)}`,
          isDomestic: false,
          id: item.hotelNumber,
          price: item?.minPrice ?? 0,
        }));
      }
      if (data.result?.localTourList && data.result?.localTourList.length > 0) {
        localTour = data.result?.localTourList.map((item) => ({
          image: item.image ?? '',
          type: 'LocalTour',
          title: item.itemName ?? '',
          time: item.createdAt ? `· ${moment(item.createdAt).format('YYYY.MM.DD(ddd)')}` : '',
          code: item.recentlyViewNo?.toString() ?? '',
          viewDate: `${moment(item.createdAt)}`,
          id: item.itemCode,
          price: item?.salesPrice,
        }));
      }
      setDataRecently([...product, ...airline, ...hotel, ...localTour]);
      product = [];
      airline = [];
      hotel = [];
      localTour = [];
    } else {
      setDataRecently([]);
    }
  }, [data?.result]);

  useEffect(() => {
    if (dataRecently && dataRecently.length > 0) {
      const groupedProduct: ProductSort[] = Object.entries(
        dataRecently.reduce((groups: { [key: string]: ProductType[] }, product) => {
          const { viewDate } = product;
          if (!groups[`${moment(viewDate).format('YYYY.MM.DD')}`]) {
            groups[`${moment(viewDate).format('YYYY.MM.DD')}`] = [];
          }
          groups[`${moment(viewDate).format('YYYY.MM.DD')}`].push(product);
          return groups;
        }, {})
      ).map(([viewDate, products]) => ({ viewDate, product: products }));

      if (groupedProduct.length > 1) {
        groupedProduct.sort((a, b) => moment(b.viewDate).diff(moment(a.viewDate)));
        setDataRecentlySort(groupedProduct);
      } else {
        setDataRecentlySort(groupedProduct);
      }
    } else {
      setDataRecentlySort([]);
    }
  }, [dataRecently]);

  return (
    <Skeleton
      className="pt-[20px]"
      loading={isLoading}
      paragraph={{
        rows: 2,
      }}
    >
      <>
        <div className="text-[15px] leading-[19px] h-[18px] text-[#AAAAAA] mt-[17px] mb-[16px] mx-5">
          최대 50개까지 저장됩니다.
        </div>
        <div className="border-b border-b-[#E0E0E0]" />
        {dataRecentlySort.length > 0 ? (
          <ProductAll dataRecently={dataRecentlySort} isLoading={isFetching} refetch={refetch} />
        ) : (
          <RecentSearchNoData />
        )}
      </>
    </Skeleton>
  );
};

export default RecentlyProductAll;
